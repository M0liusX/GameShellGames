#!/bin/bash

exec GameshellTemplate.x86
