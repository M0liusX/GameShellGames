#!/bin/bash

exec GameShellTemplate.x86
